import React, { useState } from 'react';
import { mockPositions } from '../constants';
import type { Position } from '../types';

const PositionsPanel: React.FC = () => {
    const [activeTab, setActiveTab] = useState('Position');
    const tabs = ['Position', 'Pending Orders', 'History'];

    const headers = [
        "Transaction", "Direction", "Lots", "Lower price", "Current price", 
        "Set Profit", "Set Loss", "Handling fee", "Margin", "Profit", 
        "Open time", "Operation"
    ];

    return (
        <div className="bg-panel-bg border-t border-border-color h-56 flex flex-col shrink-0">
            <div className="flex items-center border-b border-border-color px-4">
                {tabs.map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`py-2 px-4 text-sm font-semibold transition-colors ${
                            activeTab === tab 
                                ? 'text-text-primary border-b-2 border-accent-green' 
                                : 'text-text-secondary hover:text-text-primary'
                        }`}
                    >
                        {tab}
                    </button>
                ))}
            </div>
            <div className="flex-grow overflow-auto text-xs">
                <div className="w-full min-w-[1000px]">
                    <div className="grid grid-cols-12 gap-4 bg-base-bg p-2 sticky top-0">
                        {headers.map(h => <div key={h} className="text-text-secondary font-semibold text-left">{h}</div>)}
                    </div>
                    <div className="divide-y divide-border-color">
                        {mockPositions.map((pos: Position) => (
                            <div key={pos.transaction} className="grid grid-cols-12 gap-4 p-2 items-center hover:bg-gray-800">
                                <div className="text-text-primary">{pos.transaction}</div>
                                <div>
                                    <span className={`px-2 py-0.5 rounded text-white text-xs ${
                                        pos.direction === 'Buy' ? 'bg-accent-green' : 'bg-accent-red'
                                    }`}>
                                        {pos.direction}
                                    </span>
                                </div>
                                <div className="text-text-primary">{pos.lots}</div>
                                <div className="text-text-primary">{pos.lowerPrice.toFixed(6)}</div>
                                <div className="text-text-primary">{pos.currentPrice.toFixed(2)}</div>
                                <div className="text-text-primary">{pos.setProfit}</div>
                                <div className="text-text-primary">{pos.setLoss}</div>
                                <div className="text-text-primary">{pos.fee}</div>
                                <div className="text-text-primary">{pos.margin.toFixed(6)}</div>
                                <div className={`${pos.profit >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                                    {pos.profit.toFixed(4)}
                                </div>
                                <div className="text-text-secondary">{pos.openTime}</div>
                                <div>
                                    <button className="text-blue-500 hover:underline">
                                        Close position
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PositionsPanel;
