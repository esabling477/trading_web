
import React, { useState } from 'react';
import type { Instrument } from '../types';

interface InstrumentsPanelProps {
    instruments: Instrument[];
    selectedInstrument: Instrument;
    onSelectInstrument: (instrument: Instrument) => void;
}

const InstrumentsPanel: React.FC<InstrumentsPanelProps> = ({ instruments, selectedInstrument, onSelectInstrument }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredInstruments = instruments.filter(inst => 
        inst.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <aside className="bg-panel-bg border-r border-border-color w-60 flex flex-col shrink-0">
            <div className="p-2 border-b border-border-color">
                <div className="relative">
                    <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary"></i>
                    <input
                        type="text"
                        placeholder="Select"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-base-bg border border-border-color rounded py-1.5 pl-9 pr-3 text-text-primary placeholder-text-secondary focus:outline-none focus:border-accent-green"
                    />
                </div>
            </div>
            <ul className="overflow-y-auto flex-grow">
                {filteredInstruments.map(instrument => {
                    const isPositive = instrument.change >= 0;
                    return (
                        <li
                            key={instrument.id}
                            onClick={() => onSelectInstrument(instrument)}
                            className={`flex justify-between items-center px-3 py-2 cursor-pointer transition-colors ${
                                selectedInstrument.id === instrument.id ? 'bg-gray-700' : 'hover:bg-gray-800'
                            }`}
                        >
                            <span className="font-semibold text-text-primary">{instrument.name}</span>
                            <span className="text-text-primary">{instrument.price.toLocaleString()}</span>
                            <span className={`font-semibold ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>
                                {isPositive ? '+' : ''}{instrument.change.toFixed(2)}%
                            </span>
                        </li>
                    );
                })}
            </ul>
        </aside>
    );
};

export default InstrumentsPanel;
