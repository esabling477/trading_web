
import React, { useState } from 'react';
import type { Instrument } from '../types';

interface TradingPanelProps {
    instrument: Instrument;
}

const LotSelector: React.FC = () => {
    const [lots, setLots] = useState(0.01);
    const step = 0.01;

    const handleIncrement = () => setLots(prev => parseFloat((prev + step).toFixed(2)));
    const handleDecrement = () => setLots(prev => Math.max(step, parseFloat((prev - step).toFixed(2))));

    return (
        <div className="flex items-center bg-base-bg border border-border-color rounded overflow-hidden">
            <button onClick={handleDecrement} className="px-3 py-1 text-text-secondary hover:bg-gray-700">-</button>
            <input 
                type="text" 
                value={lots.toFixed(2)} 
                onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (!isNaN(val)) setLots(val);
                }}
                className="w-full text-center bg-transparent focus:outline-none"
            />
            <button onClick={handleIncrement} className="px-3 py-1 text-text-secondary hover:bg-gray-700">+</button>
        </div>
    );
};

const TradingPanel: React.FC<TradingPanelProps> = ({ instrument }) => {
    return (
        <aside className="bg-panel-bg border-l border-border-color w-72 flex flex-col shrink-0 p-4 gap-4">
            <div className="text-center">
                <p className="text-text-secondary">VIP:</p>
                <p className="text-2xl font-semibold text-text-primary">$15,215.130778</p>
                <div className="flex justify-between text-xs text-text-secondary mt-1">
                    <span>Credit score: 100</span>
                    <span>UID: 9210000</span>
                </div>
            </div>

            <div className="flex flex-col gap-3">
                <div className="flex bg-base-bg rounded-md p-1">
                    <button className="flex-1 py-1 rounded-md bg-gray-600 text-text-primary text-sm">Contract</button>
                    <button className="flex-1 py-1 rounded-md text-text-secondary text-sm hover:bg-gray-700">Future</button>
                </div>
                
                <div className="flex justify-between items-center bg-base-bg p-2 rounded">
                    <span className="font-bold text-text-primary">{instrument.name}</span>
                    <span className="font-semibold text-accent-green">{instrument.price.toLocaleString()}</span>
                </div>

                <div className="flex flex-col gap-2 text-sm">
                    <div className="flex justify-between items-center">
                        <label className="text-text-secondary">Set Loss</label>
                        <input type="text" defaultValue="0" className="w-2/3 bg-base-bg border border-border-color rounded p-1 text-right focus:outline-none focus:border-accent-green" />
                    </div>
                     <div className="flex justify-between items-center">
                        <label className="text-text-secondary">Set Profit</label>
                        <input type="text" defaultValue="0" className="w-2/3 bg-base-bg border border-border-color rounded p-1 text-right focus:outline-none focus:border-accent-green" />
                    </div>
                     <div className="flex justify-between items-center">
                        <label className="text-text-secondary">Lots (Step: 0.01)</label>
                        <div className="w-2/3">
                            <LotSelector />
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-2">
                    <button className="w-full py-3 rounded font-bold text-white bg-accent-green hover:bg-emerald-600 transition-colors">Buy</button>
                    <button className="w-full py-3 rounded font-bold text-white bg-accent-red hover:bg-red-600 transition-colors">Sell</button>
                </div>
            </div>
        </aside>
    );
};

export default TradingPanel;
