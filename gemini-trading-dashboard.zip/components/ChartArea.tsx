
import React from 'react';
import type { Instrument } from '../types';

interface ChartAreaProps {
    instrument: Instrument;
}

const timeframes = ['1M', '5M', '15M', '30M', '1H', '1D'];

const ChartArea: React.FC<ChartAreaProps> = ({ instrument }) => {
    return (
        <section className="bg-base-bg flex flex-col flex-grow">
            <div className="flex items-center justify-between p-2 border-b border-border-color shrink-0">
                <span className="font-bold text-lg text-text-primary">{instrument.name}</span>
                <div className="flex items-center gap-1">
                    {timeframes.map(tf => (
                        <button key={tf} className="px-2 py-1 text-xs text-text-secondary hover:bg-gray-700 hover:text-white rounded transition-colors">
                            {tf}
                        </button>
                    ))}
                </div>
                <div className="flex items-center gap-4 text-text-secondary">
                    <span>Indicator</span>
                    <i className="fas fa-cog cursor-pointer hover:text-white"></i>
                    <i className="fas fa-search-plus cursor-pointer hover:text-white"></i>
                    <i className="fas fa-search-minus cursor-pointer hover:text-white"></i>
                </div>
            </div>
            <div className="flex-grow p-1">
                {/* Placeholder for the actual chart library */}
                <img 
                    src="https://i.imgur.com/k91nL9N.png" 
                    alt="Candlestick chart placeholder" 
                    className="w-full h-full object-cover"
                />
            </div>
        </section>
    );
};

export default ChartArea;
