
import React, { useState } from 'react';
import { sidebarIcons } from '../constants';
import type { SidebarIcon } from '../types';

const IconSidebar: React.FC = () => {
    const [activeIcon, setActiveIcon] = useState('chart');

    return (
        <aside className="bg-panel-bg border-r border-border-color flex flex-col items-center py-4 w-14 shrink-0">
            {sidebarIcons.map((item: SidebarIcon) => (
                <a
                    key={item.id}
                    href="#"
                    onClick={() => setActiveIcon(item.id)}
                    className={`w-10 h-10 flex items-center justify-center rounded-lg mb-2 transition-colors text-lg
                        ${activeIcon === item.id ? 'bg-accent-green text-white' : 'text-text-secondary hover:bg-gray-700 hover:text-white'}`}
                >
                    <i className={item.iconClass}></i>
                </a>
            ))}
        </aside>
    );
};

export default IconSidebar;
