
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="bg-panel-bg border-b border-border-color flex items-center justify-between px-4 h-14 shrink-0">
            <div className="flex items-center gap-4">
                <div className="text-xl font-bold text-text-primary">GTC</div>
                <button className="px-4 py-1.5 text-sm font-semibold rounded bg-accent-green text-white hover:bg-emerald-600 transition-colors">
                    Product List
                </button>
                <button className="px-4 py-1.5 text-sm font-semibold rounded bg-gray-600 text-text-primary hover:bg-gray-500 transition-colors">
                    Submit Order
                </button>
            </div>
            <div className="flex items-center gap-6 text-sm text-text-secondary">
                <a href="#" className="hover:text-text-primary transition-colors">Financial</a>
                <a href="#" className="hover:text-text-primary transition-colors">English</a>
                <a href="#" className="hover:text-text-primary transition-colors">Login</a>
                <a href="#" className="px-4 py-1.5 font-semibold rounded bg-blue-600 text-white hover:bg-blue-500 transition-colors">
                    Register
                </a>
            </div>
        </header>
    );
};

export default Header;
